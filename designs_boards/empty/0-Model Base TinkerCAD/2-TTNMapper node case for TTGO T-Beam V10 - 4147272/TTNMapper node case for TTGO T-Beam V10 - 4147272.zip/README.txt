TTNMapper node case for TTGO T-Beam V10 by Noppingen on Thingiverse: https://www.thingiverse.com/thing:4147272

Summary:
A case for the Heltec TTGO "T-Beam V10" board.Hardware:TTGO T-Beam V10 (https://www.amazon.de/gp/product/B07RWY36ZY/ref=ppx_yo_dt_b_asin_title_o03_s00?ie=UTF8)AZDelivery GPS Antenna (https://www.az-delivery.de/products/neo-6m-gps-antennen-modul) - a major improvement, the antenna fits between board and case face.More (in German):https://www.onderka.com/computer-und-netzwerk/ttnmapper-node-mit-ttgo-t-beam-v10